// Question: Find the simple interest for $2500 at 4% interest rate for 5 years.

let principal=2500;
let rate=4;
let time=5;

let interest= (principal * rate * time) /100;

console.log(interest);