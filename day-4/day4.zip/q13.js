// Question: Determine the total bill amount including 12% tax for a purchase of $80.

let  initial_amount=80;
let tex_rate=12;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);