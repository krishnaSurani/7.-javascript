// Question: Find the sum of three numbers.

let a=10;
let b=20; 
let c=30;

console.log(" Sum:", a + b +c);