// Question: Determine the total bill amount including 5% tax for a purchase of $120.

let  initial_amount=120;
let tex_rate=5;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);