// Question: Multiply three numbers.

let a=3;
let b=4;
let c=5;

console.log(" Product: ", a*b*c);