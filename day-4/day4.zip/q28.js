// Question: Calculate the total bill amount including 25% tax, 15% tip, and a $20 service charge for a purchase of $200.

