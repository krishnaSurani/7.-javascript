// Question: Calculate the annual salary of an employee paid $40 per hour for 2400 hours .

let paid=40;
let hours=2400;

console.log(" annual salary :", paid * hours);