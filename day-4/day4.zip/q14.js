// Question: Calculate the simple interest for $2000 at 3% interest rate for 4 years.

let principal=2000;
let rate=3;
let time=4;

let interest= (principal * rate * time) /100;

console.log(interest);