// Question: Calculate the annual salary of an employee paid $30 per hour for 2000 hours.

let paid=30;
let hours=2000;

console.log("monthly salary :", paid * hours);