// Question: Calculate the monthly salary of an employee paid $18 per hour for 180 hours.

let paid=18;
let hours=180;

console.log("monthly salary :", paid * hours);