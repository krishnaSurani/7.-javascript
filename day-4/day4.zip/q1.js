// Question: Calculate the sum of two numbers.

let a=5;
let b=7;

console.log("the sum of two number =",a + b);