// Question: Find the remainder when one number is divided by another.

let a=25;
let b=7;

console.log("Remainder:", a%b);