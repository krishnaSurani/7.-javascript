// Question: Find the simple interest for $5000 at 3.5% interest rate for 10 years.

let principal=5000;
let rate=3.5;
let time=10;

let interest= (principal * rate * time) /100;

console.log(interest);