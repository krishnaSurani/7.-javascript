// Question: Find the simple interest for $4500 at 6% interest rate for 7 years.


let principal=4500;
let rate=6;
let time=7;

let interest= (principal * rate * time) /100;

console.log(interest);