// Question: Calculate the total bill amount including 8% tax for a purchase of $50.

let  initial_amount=50;
let tex_rate=8;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);