// Question: Divide one number by another.

let a=20;
let b=5;

console.log("Quotient:",a/b);