// Question: Calculate the monthly salary of an employee paid $25 per hour for 160 hours.

let a=25;
let b=160;

console.log(" Monthly salary :$",a*b);