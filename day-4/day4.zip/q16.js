// Question: Calculate the total bill amount including a 10% tip for a meal costing $60.

let  initial_amount=60;
let tex_rate=10;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);