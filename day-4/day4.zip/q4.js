// Calculate the weekly salary of an employee paid $15 per hour for 40 hours.

let per_hour=15
let totalhours=40;

let Weekly_salary=15*40

console.log("Weekly salary is =",Weekly_salary);