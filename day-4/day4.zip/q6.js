// Question: Calculate the total bill amount including a 15% tip for a meal costing $40.

let  initial_amount=40;
let tex_rate=15;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);