// Question: Find the simple interest for $1000 at 5% interest rate for 2 years.

let principal=1000;
let rate=5;
let time=2;

let interest= (principal * rate * time) /100;

console.log(interest);