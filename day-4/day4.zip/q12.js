// Question: Find the total cost for 3 items priced $15 each.

let items=3;
let priced=15;

console.log("Total cost :", items * priced);