// Question: Find the product of two numbers.

let a=8;
let b=4;

console.log(" Product :", a*b);