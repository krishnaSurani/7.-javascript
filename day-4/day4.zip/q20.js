// Question: Calculate the total bill amount including 7% tax for a purchase of $90.

let  initial_amount=90;
let tex_rate=7;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);