// Question: Determine the total bill amount including a 20% tip and 10% tax for a meal costing $100.

let  initial_amount=100;
let tex_rate=10;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);



let amout=110;
let tip=20;
let bill2=amout * (tip /100);
let totalbill2=bill2 + amout;

console.log("Total bill amount: ", totalbill2);