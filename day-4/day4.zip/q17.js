// Question: Determine the compound interest for $7000 at 5% compounded annually for 2 years.

let principal=7000;
let rate=5;
let time=2;

let interest= (principal * rate * time) /100;

console.log(interest);