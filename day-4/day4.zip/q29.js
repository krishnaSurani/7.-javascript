// Question: Determine the total bill amount including 10% tax and a $15 delivery fee for a purchase of $300 with a $50 discount.
