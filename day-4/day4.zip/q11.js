// Question: Calculate the difference between two numbers.

let a=15;
let b=8;

console.log("Difference:", a-b);