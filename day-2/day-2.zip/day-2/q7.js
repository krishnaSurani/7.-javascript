var data=null;


console.log(data);
console.log(typeof data);