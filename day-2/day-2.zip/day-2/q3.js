const pi=3.1415;

pi=86;

console.log(pi);