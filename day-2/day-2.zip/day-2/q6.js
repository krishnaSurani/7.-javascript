var result;

console.log(typeof result);