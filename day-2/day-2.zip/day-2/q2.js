var a="Alice";

a="Bob";

console.log(a);