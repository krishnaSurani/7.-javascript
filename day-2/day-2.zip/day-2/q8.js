let name="Alice";

let n=`Hello, ${name}`

console.log(n);