let isAvailable=10;

console.log(typeof isAvailable);