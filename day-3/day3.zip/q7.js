// Q. 7 Calculate the total salary of an employee. Given the basic salary and allowances, calculate the total salary.

let  basic_salary=2000;
let allowances=500;
let total_salary=basic_salary + allowances;


console.log("basic saralr =",basic_salary);
console.log("aloowance = ",allowances);
console.log("total salary is =",total_salary);