// Q.2 Write a Program to find the area of a rectangle.

let length=50;
let width=40;

let area=length*width;

console.log(area);