// Q.6 Calculate the total bill amount including tax. Given an initial amount and a tax rate, calculate the total bill amount.

let  initial_amount=100;
let tex_rate=10;

let bill=initial_amount * (tex_rate / 100);

let totalbill=bill + initial_amount;

console.log(totalbill);