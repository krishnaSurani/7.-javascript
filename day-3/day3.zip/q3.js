// Q.3 Write a Program to find the area of a triangle.

let b=25;
let h=10;

let area=1/2 * b * h;

console.log(area);