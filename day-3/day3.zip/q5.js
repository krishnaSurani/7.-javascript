// Q.5 Write a Program to find the Perimeter of the circle.

let pi=3.14;
let radius=20;

let perimeter=2 * pi * radius;

console.log(perimeter);