// Q. 8 Swap the values of two variables without using a function. Given two variables, swap their values.

let x=5;
let y=10;
let z;

z=x;
x=y;
y=z;

console.log(x);
console.log(y);
