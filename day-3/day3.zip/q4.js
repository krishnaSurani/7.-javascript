// Q.4 Write a Program to find Simple interest.

let principal=1000;
let rate=5;
let time=3;

let interest= (principal * rate * time) /100;

console.log(interest);