// Q.1 Write a Program to find the area of a circle.

let pi=3.14;

let r=10;

let area=pi*r*r;

console.log(area);